import {pageTarget,projectData,imageFile,cdnImage} from './assets.js';
import {readInTab} from './tab.js';

const el=id=>document.getElementById(id);
const say=message=>el('status').textContent=message;
const safe=value=>String(value).replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').replace(/^[. ]+|[. ]+$/g,'').slice(0,90)||'ArtStation';
let current=null,items=[],version=0,lookup=0,saving=false,pending=false,timer;
const managedURLs=new Set();
function clearLinks(){
 el('files').replaceChildren();
 for(const url of managedURLs)URL.revokeObjectURL(url);
 managedURLs.clear();
}
async function active(){
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
 const parsed=pageTarget(tab?.url);
 return parsed?{tab:tab.id,url:tab.url,pageTitle:tab.title,expected:new URL(tab.url).href.split('#')[0],...parsed}:null;
}
function controls(){
 const count=items.filter(i=>i.selected).length,project=!!current?.id;
 el('tools').hidden=!items.length;
 el('all').checked=!!items.length&&count===items.length;
 el('all').indeterminate=count>0&&count<items.length;
 el('all').disabled=saving;
 el('save').disabled=saving||(!project&&!current?.album&&!count);
 el('save').textContent=project?(count?'下载所选 · '+count+' 张':'下载整组 · '+items.length+' 张'):current?.album&&!count?'下载整个系列 · '+items.length+' 部':'下载所选 · '+count+' 部';
 el('reload').disabled=saving;
 for(const item of items)if(item.box)item.box.disabled=saving;
}
function render(){
 const fragment=document.createDocumentFragment();
 for(const item of items){
  const card=document.createElement(current?.artist?'div':'label');card.className='card';
  const box=document.createElement('input');box.type='checkbox';box.checked=!!item.selected;
  box.onchange=()=>{item.selected=box.checked;controls()};item.box=box;box.setAttribute('aria-label','选择 '+item.title);card.append(box);
  const preview=current?.artist?document.createElement('button'):card;
  if(preview!==card){
   preview.className='open';preview.title='打开 '+item.title;
   const ctx=current;
   preview.onclick=async()=>{
    if(saving)return;
    const u=new URL(ctx.url);
    u.pathname=(/^(www\.)?artstation\.com$/.test(u.hostname)?'/artwork/':'/projects/')+encodeURIComponent(item.id);
    u.search='';if(ctx.album)u.searchParams.set('album_id',ctx.album);u.hash='';
    try{await chrome.tabs.update(ctx.tab,{url:u.href})}catch{say('无法打开作品，请在 ArtStation 页面点作品封面。')}
   };
   card.append(preview);
  }
  if(item.thumb){
   const img=document.createElement('img');img.loading='lazy';img.alt='';
   img.src=item.thumb.replace(/\/(large|4k|8k|original)\/(?=[^/]+(?:\?|$))/,'/small/');
   img.onerror=()=>img.remove();preview.append(img);
  }
  const title=document.createElement('span');title.textContent=item.title;preview.append(title);fragment.append(card);
 }
 el('grid').replaceChildren(fragment);controls();
}
async function queryTab(context,params){
 let result;
 try{
  const [execution]=await chrome.scripting.executeScript({target:{tabId:context.tab},func:readInTab,args:[{...params,expected:context.expected}]});
  result=execution?.result;
 }catch(e){
  if(/cannot access|permission|not allowed/i.test(e.message))throw Error('扩展没有读取当前页面的权限。请允许 Artstation DL 访问此网站，并刷新 ArtStation 标签页。');
 }
 if(result?.error)throw Error(result.error);
 if(result&&!result.fallback)return result;
 const endpoint=params.id?'/projects/'+params.id+'.json':'/users/'+params.artist+'/projects.json?album_id='+(params.album||'all')+'&page='+params.page;
 const r=await fetch('https://www.artstation.com'+endpoint,{credentials:'include',signal:AbortSignal.timeout(18000)});
 if(!r.ok){
  if(r.status===403){
   const artist=context.artist||result?.artist;
   if(artist&&/^[a-z0-9_-]+$/i.test(artist)){
    const alternate=await readArtistSite(artist,params.id,params.album);
    if(alternate)return alternate;
   }
   throw Error(params.id?'ArtStation 拒绝了作品数据请求，页面中也没有读到可用的作品图。':'ArtStation 拒绝了作品列表请求。请等画师主页显示封面后点「重新读取」。');
  }
  throw Error('ArtStation 暂时无法读取（'+r.status+'）');
 }
 const data=await r.json();
 if(params.id)return {data};
 if(!Array.isArray(data.data))throw Error('画师作品列表读取不完整');
 return {projects:data.data.filter(p=>p.hash_id).map(p=>({id:p.hash_id,title:p.title||p.hash_id,thumb:p.smaller_square_cover_url||p.cover?.small_square_url||''})),total:data.total_count};
}
async function readArtistSite(artist,id,album){
 const base='https://'+artist+'.artstation.com/';
 const r=await fetch(base+(id?'projects/'+encodeURIComponent(id):album?'albums/'+album:''),{credentials:'omit',signal:AbortSignal.timeout(15000)});
 if(!r.ok||(album&&r.url&&new URL(r.url).pathname.replace(/\/$/,'')!=='/albums/'+album))return null;
 const doc=new DOMParser().parseFromString(await r.text(),'text/html');
 if(!id){
  const projects=new Map();
  for(const a of doc.querySelectorAll('a[href]')){
   const u=new URL(a.getAttribute('href'),base);
   const m=u.pathname.match(/^\/projects\/([a-z0-9]+)\/?$/i);
   if(!m||u.origin!==new URL(base).origin||(album&&u.searchParams.has('album_id')&&u.searchParams.get('album_id')!==album))continue;
   const img=a.querySelector('img');
   projects.set(m[1],{id:m[1],title:a.textContent.trim()||img?.alt||projects.get(m[1])?.title||m[1],thumb:img?.getAttribute('data-src')||img?.getAttribute('src')||projects.get(m[1])?.thumb||''});
  }
  return projects.size?{projects:[...projects.values()],complete:true}:null;
 }
 const images=new Map();
 const area=doc.querySelector('.project-assets, .asset-list')||doc;
 for(const n of area.querySelectorAll('img,source,a[href]')){
  const raw=n.getAttribute('data-src')||n.getAttribute('src')||n.getAttribute('href')||n.getAttribute('srcset')?.split(/\s+/)[0];
  if(!raw)continue;
  const u=new URL(raw,base);
  if(cdnImage(u.href)&&!u.pathname.includes('_square/'))images.set(u.pathname.replace(/\/(small|medium|large|4k|8k|original)\/(?=[^/]+$)/,'/'),u.href);
 }
 return images.size?{visible:{title:doc.querySelector('h1')?.textContent||id,images:[...images.values()]}}:null;
}
async function project(context,id){
 const res=await queryTab(context,{id});
 const group=res.visible||projectData(res.data,id);
 if(!group)throw Error('无法读取这部作品的图片');
 return group;
}
async function load(force=false){
 if(saving){pending=true;return}
 const search=++lookup;
 const ctx=await active();
 if(search!==lookup||saving)return;
 if(!force&&ctx?.tab===current?.tab&&ctx?.expected===current?.expected&&current)return;
 const ticket=++version;
 current=ctx;items=[];clearLinks();render();el('title').textContent='';
 if(!ctx){say('请打开 ArtStation 的作品页、系列页或画师主页。');return}
 say('正在读取当前页面…');
 try{
  let list,title;
  if(ctx.id){
   const d=await project(ctx,ctx.id);let index=0;
   list=d.images.map((url,i)=>({url,index:i,title:new URL(url).pathname.includes('/assets/covers/')?'封面':'图片 '+(++index),thumb:url}));
   title=d.title;ctx.title=title;
  }else{
   const unique=new Map();title=ctx.album?(ctx.pageTitle?.replace(/^ArtStation\s*[-–|]\s*/i,'').trim()||'系列 '+ctx.album):ctx.artist;
   for(let page=1;;page++){
    const d=await queryTab(ctx,{artist:ctx.artist,album:ctx.album,page});if(ticket!==version)return;
    const before=unique.size;for(const p of d.projects)unique.set(p.id,p);
    if(d.complete||unique.size===before||(d.total!=null&&unique.size>=d.total))break;
   }
   list=[...unique.values()];if(ctx.album)ctx.title=ctx.artist+'-'+ctx.album;
  }
  if(ticket!==version)return;
  items=list;el('title').textContent=title;say(ctx.id?'共 '+items.length+' 张图片 · 最高可用画质':(ctx.album?'本系列 ':'共 ')+items.length+' 部作品 · 点封面打开，勾选可批量下载');render();
 }catch(e){if(ticket===version)say(e.message.includes('ArtStation')||e.message.includes('作品')||e.message.includes('页面')?e.message:'暂时无法读取当前页。请检查网络后点「重新读取」。')}
}
async function save(){
 if(saving||!current)return;
 const selected=items.filter(i=>i.selected);
 const chosen=(current.id||current.album)&&!selected.length?items:selected;
 if(!chosen.length)return;
 const ctx=current;saving=true;controls();clearLinks();
 let zip=new JSZip(),size=0,part=0,done=0,failed=0,firstError='';
 function fail(e){failed++;firstError||=e.message}
 async function flush(){
  if(!size)return;
  say('正在生成 ZIP…');
  const blob=await zip.generateAsync({type:'blob',compression:'STORE'}),url=URL.createObjectURL(blob);managedURLs.add(url);
  const filename=safe(ctx.title||ctx.artist)+'-'+(++part)+'.zip';
  const link=document.createElement('a');link.href=url;link.download=filename;link.textContent='保存 '+filename;el('files').append(link);
  await chrome.downloads.download({url,filename,saveAs:false}).catch(()=>{});
  zip=new JSZip();size=0;
 }
 try{
  const groups=ctx.id?[{id:ctx.id,title:ctx.title}]:chosen;
  for(const [g,p] of groups.entries()){
   let d;try{d=ctx.id?{images:chosen.map(i=>i.url),title:p.title}:await project(ctx,p.id)}catch(e){fail(e);continue}
   if(!d.images.length){fail(Error('所选作品没有可下载图片'));continue}
   for(const [i,url] of d.images.entries()){
    say('作品 '+(g+1)+' / '+groups.length+'　图片 '+(i+1)+' / '+d.images.length);
    try{
     const {bytes,ext}=await imageFile(url);
     if(size+bytes.byteLength>200*1024*1024)await flush();
     const n=ctx.id?chosen[i].index+1:i+1;
     zip.file(safe(d.title)+'_'+p.id+'/'+String(n).padStart(3,'0')+'.'+ext,bytes);
     size+=bytes.byteLength;done++;
    }catch(e){fail(e)}
   }
  }
  await flush();say('已打包 '+done+' 张图片'+(failed?'，'+failed+' 项未能下载。'+firstError:'。'));
 }catch{say('打包失败，请重试。')}finally{saving=false;controls();if(pending){pending=false;schedule()}}
}
function schedule(){clearTimeout(timer);timer=setTimeout(()=>load(),180)}
el('all').onchange=()=>{for(const i of items)i.selected=i.box.checked=el('all').checked;controls()};
el('save').onclick=save;el('reload').onclick=()=>load(true);
chrome.tabs.onActivated.addListener(schedule);
chrome.tabs.onUpdated.addListener((_,change,tab)=>{if(tab.active&&(change.url||change.status==='complete'))schedule()});
load(true);
