export function pageTarget(address){
 let u;try{u=new URL(address)}catch{return null}
 if(u.protocol!=='https:'||!/(^|\.)artstation\.com$/.test(u.hostname))return null;
 const path=u.pathname.replace(/^\/|\/$/g,'');
 const project=path.match(/^(?:artwork|projects)\/([a-z0-9]+)$/i);
 if(project)return {id:project[1]};
 const main=['www.artstation.com','artstation.com'].includes(u.hostname);
 const albumPath=main?path.match(/^([\w-]+)\/albums\/(\d+|all)$/):path.match(/^albums\/(\d+|all)$/);
 const artist=main?(albumPath?.[1]||path.replace(/\/albums$/,'')):u.hostname.split('.')[0];
 const album=albumPath?.at(-1)||u.searchParams.get('album_id');
 if(!/^[\w-]+$/.test(artist)||/^(marketplace|learning|channels|search|jobs|artwork|projects|prints|blogs|challenges|settings|about|magazine|cdn\w*)$/.test(artist))return null;
 if(!main&&path&&!albumPath&&!['projects','albums','albums/all'].includes(path))return null;
 if(album&&album!=='all')return /^\d+$/.test(album)?{artist,album}:null;
 return {artist};
}
export function cdnImage(raw){
 try{const u=new URL(raw);return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&/^cdn[a-z0-9-]*\.artstation\.com$/.test(u.hostname)&&/^\/p\/assets\/(?:images|covers)\//.test(u.pathname)}catch{return false}
}
export function projectData(data,id){
 if(!Array.isArray(data?.assets))return null;
 const images=data.assets.filter(a=>(!a.asset_type||['cover','image'].includes(a.asset_type))&&cdnImage(a.image_url)).map(a=>a.image_url);
 return {title:data.title||id,images:[...new Set(images)]};
}
export function candidates(raw){
 if(!cdnImage(raw))throw Error('无效的作品图片地址');
 const source=new URL(raw),urls=new Set();
 const tier=/\/(small_square|smaller_square|small|medium|large|4k|8k|original)\/(?=[^/]+$)/;
 const paths=source.pathname.includes('/original/')?[source.pathname]:['8k','4k','large'].map(t=>source.pathname.replace(tier,'/'+t+'/'));
 for(const path of [...paths,source.pathname]){
  const u=new URL(raw);u.pathname=path;
  if(!u.searchParams.has('dl'))u.search+=(u.search?'&':'?')+'dl=1';else if(u.searchParams.get('dl')!=='1')u.searchParams.set('dl','1');
  urls.add(u.href);const original=new URL(raw);original.pathname=path;urls.add(original.href);
 }
 return [...urls];
}
export async function imageFile(raw){
 for(const url of candidates(raw)){
  let r;try{r=await fetch(url,{signal:AbortSignal.timeout(30000)})}catch{continue}
  if(r.status===429)throw Error('ArtStation 请求过于频繁，请稍后重试');
  const type=(r.headers.get('content-type')||'').split(';')[0];
  if(r.ok&&type.startsWith('image/')){
   const bytes=await r.arrayBuffer();
   if(bytes.byteLength)return {bytes,ext:({'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/avif':'avif','image/gif':'gif'})[type]||'img'};
  }else await r.body?.cancel();
 }
 throw Error('图片服务器没有返回可下载的文件');
}
