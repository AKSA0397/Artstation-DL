// This function is serialized into the current ArtStation tab by Chrome.
export async function readInTab(request){
 const {artist,id,page,album,expected}=request;
 if(location.href.split('#')[0]!==expected)return {error:'当前页面已切换，请重新读取'};
 const project=Boolean(id);
 const endpoint=project?'/projects/'+id+'.json':'/users/'+artist+'/projects.json?album_id='+(album||'all')+'&page='+page;
 try{
  const r=await fetch(endpoint,{credentials:'same-origin',signal:AbortSignal.timeout(10000)});
  if(r.ok){
   const d=await r.json();
   if(project&&Array.isArray(d.assets))return {data:{title:d.title,assets:d.assets.map(a=>({asset_type:a.asset_type,image_url:a.image_url}))}};
   if(!project&&Array.isArray(d.data))return {projects:d.data.filter(x=>x.hash_id).map(x=>({id:x.hash_id,title:x.title||x.hash_id,thumb:x.smaller_square_cover_url||x.cover?.small_square_url||x.cover?.thumb_url||''})),total:d.total_count};
  }
 }catch{}
 if(document.querySelector('#challenge-stage, #challenge-running, form#challenge-form'))return {error:'请先在当前 ArtStation 页面完成验证，再点重新读取。'};
 // A profile tab cannot supply the DOM of a different project.
 if(project&&!location.pathname.match(new RegExp('/(?:artwork|projects)/'+id+'/?$')))return {fallback:true};
 const content=(project&&document.querySelector('.project-assets,.asset-list'))||document.querySelector('main')||document.body;
 let scroll=content;
 while(scroll&&!(scroll.scrollHeight>scroll.clientHeight+2&&/auto|scroll/.test(getComputedStyle(scroll).overflowY)))scroll=scroll.parentElement;
 scroll=scroll||document.scrollingElement;
 const start=scroll.scrollTop,entries=new Map();let stable=0,height=0;
 try{
  scroll.scrollTop=0;
  const deadline=Date.now()+120000;
  while(Date.now()<deadline){
   await new Promise(resolve=>setTimeout(resolve,400));
   if(location.href.split('#')[0]!==expected)return {error:'当前页面已切换，请重新读取'};
   const before=entries.size;
   if(project){
    const media=document.querySelector('.project-assets,.asset-list')||content;
    for(const img of media.querySelectorAll('img,source,[data-src],[data-image-url],a[href]')){
     const raw=img.dataset.imageUrl||img.dataset.src||img.currentSrc||img.getAttribute('src')||img.getAttribute('href')||img.getAttribute('srcset')?.split(/\s+/)[0];if(!raw)continue;
     const u=new URL(raw,location.href);
     if(!/^cdn[a-z0-9-]*\.artstation\.com$/.test(u.hostname)||!/^\/p\/assets\/(images|covers)\//.test(u.pathname)||u.pathname.includes('_square/'))continue;
     entries.set(u.pathname.replace(/\/(small|medium|large|4k|8k|original)\/(?=[^/]+$)/,'/'),u.href);
    }
   }else{
    for(const link of content.querySelectorAll('a[href]')){
     const u=new URL(link.href),m=u.pathname.match(/^\/(artwork|projects)\/([a-z0-9]+)\/?$/i);
     if(u.origin!==location.origin||!m||(album&&u.searchParams.has('album_id')&&u.searchParams.get('album_id')!==album))continue;
     const img=link.querySelector('img'),old=entries.get(m[2]);
     entries.set(m[2],{id:m[2],title:link.title||link.textContent.trim()||img?.alt||old?.title||m[2],thumb:img?.currentSrc||img?.src||old?.thumb||''});
    }
   }
   const h=scroll.scrollHeight,bottom=scroll.scrollTop+scroll.clientHeight>=h-4;
   stable=bottom&&h===height&&before===entries.size?stable+1:0;height=h;
   if(stable>=(entries.size?6:18))break;
   scroll.scrollTop+=Math.max(350,scroll.clientHeight*.85);
  }
 }finally{if(location.href.split('#')[0]===expected)scroll.scrollTop=start}
 if(stable<6||!entries.size){
  const meta=document.querySelector('meta[property="article:author"]')?.content;
  const authorLink=document.querySelector('a[rel="author"], .project-author a[href], .artist-name a[href]');
  const author=authorLink?.href?new URL(authorLink.href):meta?.startsWith('https://')?new URL(meta):null;
  const name=author&&/^(www\.)?artstation\.com$/.test(author.hostname)?author.pathname.split('/')[1]:null;
  return {fallback:true,artist:name};
 }
 const values=[...entries.values()];
 return project?{visible:{title:document.querySelector('h1')?.textContent||document.title,images:values}}:{projects:values,complete:true};
}
