import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

// Use a separate visible Chrome window so the user can complete any site prompt.
let session;
let child;
export function closeBrowser() { child?.kill(); }
async function connect() {
  const profile = await mkdtemp(join(tmpdir(), 'artstation-browser-'));
  const chrome = spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    ['--remote-debugging-pipe','--user-data-dir='+profile,'--no-first-run','--no-default-browser-check','about:blank'],
    {stdio:['ignore','ignore','ignore','pipe','pipe']});
  child = chrome;
  let seq=0, pending=new Map(), buffer='';
  const cleanup=()=>{
    session=undefined;pageOpened=false;
    for(const callback of pending.values()) callback({error:{message:'Chrome 窗口已关闭，请重新点击下载。'}});
    void rm(profile,{recursive:true,force:true}).catch(()=>{});
  };
  chrome.once('close',cleanup);
  chrome.stdio[3].on('error',()=>{});
  chrome.stdio[4].setEncoding('utf8');
  chrome.stdio[4].on('data',chunk=>{
    buffer+=chunk;
    let end;
    while((end=buffer.indexOf('\0'))>=0){
      const msg=JSON.parse(buffer.slice(0,end));buffer=buffer.slice(end+1);
      pending.get(msg.id)?.(msg);
    }
  });
  function command(method,params={},sessionId){
    return new Promise((resolve,reject)=>{
      const id=++seq;
      const timer=setTimeout(()=>{pending.delete(id);reject(Error('Chrome 响应超时，请重新下载。'))},18000);
      pending.set(id,msg=>{clearTimeout(timer);pending.delete(id);msg.error?reject(Error(msg.error.message)):resolve(msg.result)});
      chrome.stdio[3].write(JSON.stringify({id,method,params,sessionId})+'\0');
    });
  }
  await new Promise((resolve,reject)=>{chrome.once('spawn',resolve);chrome.once('error',()=>reject(Error('无法打开 Google Chrome，请确认已安装。')))});
  const {targetInfos}=await command('Target.getTargets');
  const target=targetInfos.find(t=>t.type==='page')||await command('Target.createTarget',{url:'about:blank'});
  const {sessionId}=await command('Target.attachToTarget',{targetId:target.targetId,flatten:true});
  return (method,params)=>command(method,params,sessionId);
}
let pageOpened=false;
export async function browserJSON(url) {
  const endpoint=new URL(url);
  const c=await (session??=connect());
  if(!pageOpened){
    const match=endpoint.pathname.match(/^\/users\/([\w-]+)\//);
    const landing=match ? '/'+match[1] : endpoint.pathname.replace('/projects/','/artwork/').replace(/\.json$/,'');
    const nav=await c('Page.navigate',{url:endpoint.origin+landing});
    if(nav.errorText)throw Error('Chrome 无法连接 ArtStation。');
    pageOpened=true;
  }
  const deadline=Date.now()+(endpoint.pathname.startsWith('/projects/')?16000:120000);
  while(Date.now()<deadline){
    const expression=`(async()=>{if(location.origin!==${JSON.stringify(endpoint.origin)} || document.readyState==="loading") return null;
      try {const r=await fetch(${JSON.stringify(url)},{headers:{Accept:"application/json"}});
        if(!r.ok)return {status:r.status};return {data:await r.json()}} catch{return null}
    })()`;
    let response;
    try{response=(await c('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true})).result?.value}
    catch(e){if(!/context|navigat/i.test(e.message))throw e}
    if(response?.data)return response.data;
    if(response?.status && ![403,503].includes(response.status))throw Error('ArtStation 返回 '+response.status);
    await delay(2500);
  }
  throw Error('请在 Chrome 完成 ArtStation 验证后重试。');
}

export async function browserImage(url) {
  const c=await (session??=connect());
  const {frameTree}=await c('Page.getFrameTree',{});
  const {resource}=await c('Network.loadNetworkResource',{
    frameId:frameTree.frame.id,url,options:{disableCache:false,includeCredentials:true}
  });
  const headers=new Headers(resource.headers||{});
  const status=resource.httpStatusCode||502;
  if(!resource.stream)return new Response(null,{status});
  const handle=resource.stream;
  const body=new ReadableStream({
    async pull(controller){
      try{
        const chunk=await c('IO.read',{handle,size:262144});
        if(chunk.data)controller.enqueue(Buffer.from(chunk.data,chunk.base64Encoded?'base64':'utf8'));
        if(chunk.eof){controller.close();await c('IO.close',{handle})}
      }catch(error){controller.error(error);await c('IO.close',{handle}).catch(()=>{})}
    },
    cancel(){return c('IO.close',{handle}).catch(()=>{})}
  });
  return new Response(body,{status,headers});
}

export async function portfolioImages(user,id){
  const c=await (session??=connect());
  const url=user?'https://'+user+'.artstation.com/projects/'+id:'https://www.artstation.com/artwork/'+id;
  const page=new URL(url);
  pageOpened=false;
  const nav=await c('Page.navigate',{url});
  if(nav.errorText)throw Error('画师作品页未能打开');
  const images=new Map();
  let steady=0,previousHeight=0;
  const deadline=Date.now()+180000;
  while(Date.now()<deadline){
    await delay(500);
    const expression=`(()=>{if(location.hostname!==${JSON.stringify(page.hostname)}||location.pathname!==${JSON.stringify(page.pathname)}||document.readyState!=='complete')return null;
      const content=document.querySelector('.project-assets, .project-description-assets, .asset-list')||document.querySelector('main')||document;
      const nodes=content.querySelectorAll('img, [data-src], a[href]');
      const urls=Array.from(nodes,el=>el.dataset.src||el.currentSrc||el.src||el.href).filter(Boolean);
      let scroller=content;
      while(scroller&&!(scroller.scrollHeight>scroller.clientHeight+2&&/auto|scroll/.test(getComputedStyle(scroller).overflowY)))scroller=scroller.parentElement;
      scroller=scroller||document.scrollingElement;
      const height=scroller.scrollHeight;
      const bottom=scroller.scrollTop+scroller.clientHeight>=height-3;
      scroller.scrollTop+=Math.max(300,Math.floor(scroller.clientHeight*.85));
      return {bottom,height,title:document.querySelector('h1')?.textContent,images:urls.filter(s=>(s.includes('/p/assets/images/')||s.includes('/p/assets/covers/'))&&!s.split('/').some(x=>['small_square','smaller_square','micro_square','medium_square','small'].includes(x)))};
    })()`;
    const result=await c('Runtime.evaluate',{expression,returnByValue:true}).catch(()=>null);
    const data=result?.result?.value;
    if(!data)continue;
    const before=images.size;
    for(const url of data.images){
      const path=new URL(url).pathname;
      const key=path.replace(/\/(?:large|original|4k|8k|medium)\/(?=[^/]+$)/,'/');
      if(!images.has(key))images.set(key,url);
    }
    steady=data.bottom&&data.height===previousHeight&&images.size===before?steady+1:0;
    previousHeight=data.height;
    if(steady>=6&&images.size)return {title:data.title||id,artist:user,images:[...images.values()]};
  }
  throw Error('作品详情暂时不可读取，请在 Chrome 检查作品页后重试。');
}

function readPortfolioCards(host){
  if(location.hostname!==host || document.readyState==='loading')return null;
  const projects=[];
  for(const link of document.querySelectorAll('a[href]')){
    const u=new URL(link.href);
    const match=u.pathname.match(/^\/projects\/([a-z0-9]+)\/?$/i);
    if(!match||u.hostname!==host)continue;
    const img=link.querySelector('img');
    const id=match[1];
    projects.push({id,title:link.textContent.trim()||img?.alt||link.title||id,thumb:img?.currentSrc||img?.src||''});
  }
  const scroller=document.scrollingElement;
  const height=scroller.scrollHeight;
  const bottom=scroller.scrollTop+scroller.clientHeight>=height-4;
  scroller.scrollTop+=Math.max(400,scroller.clientHeight);
  return {projects,height,bottom};
}

export async function portfolioList(user){
  const c=await (session??=connect());
  const host=user+'.artstation.com';
  pageOpened=false;
  const nav=await c('Page.navigate',{url:'https://'+host+'/'});
  if(nav.errorText)throw Error('画师个人站未能打开');
  const expression='('+readPortfolioCards.toString()+')('+JSON.stringify(host)+')';
  const projects=new Map();
  let previousHeight=0,stable=0;
  const deadline=Date.now()+120000;
  while(Date.now()<deadline){
    await delay(600);
    const result=await c('Runtime.evaluate',{expression,returnByValue:true});
    const data=result.result?.value;
    if(!data)continue;
    const before=projects.size;
    for(const p of data.projects){if(!projects.has(p.id)||p.title!==p.id)projects.set(p.id,p)}
    stable=data.bottom&&before===projects.size&&data.height===previousHeight?stable+1:0;
    previousHeight=data.height;
    if(stable>=5&&projects.size)return {projects:[...projects.values()],complete:true,total:projects.size};
  }
  throw Error('画师个人站未返回完整作品列表');
}
