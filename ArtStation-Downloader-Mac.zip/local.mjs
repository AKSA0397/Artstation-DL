import http from 'node:http';
import {Readable} from 'node:stream';
import {spawn} from 'node:child_process';
import worker from './app.mjs';
import {browserJSON,browserImage,portfolioImages,portfolioList,closeBrowser} from './browser-access.mjs';
globalThis.artstationBrowserJSON=browserJSON;
globalThis.artstationBrowserImage=browserImage;
globalThis.artstationPortfolioImages=portfolioImages;
globalThis.artstationPortfolioList=portfolioList;
for (const signal of ['SIGTERM','SIGINT','SIGHUP']) process.once(signal,()=>{closeBrowser();process.exit()});
const server=http.createServer(async(req,res)=>{
 try{
 const origin='http://127.0.0.1:'+server.address().port;
 if(req.headers.host!==new URL(origin).host||req.method!=='GET'){res.writeHead(403).end();return}
 const response=await worker.fetch(new Request(new URL(req.url,origin)));
 res.writeHead(response.status,Object.fromEntries(response.headers));
 if(!response.body){res.end();return}
 const stream=Readable.fromWeb(response.body);
 stream.on('error',()=>res.destroy());
 res.on('close',()=>stream.destroy());
 stream.pipe(res);
 }catch{if(!res.headersSent)res.writeHead(500);res.end('读取失败，请重试。')}
});
server.listen(0,'127.0.0.1',()=>{
 const url='http://127.0.0.1:'+server.address().port;
 console.log('Artstation DL 已启动：'+url+'\n下载期间请保持此窗口打开。');
 spawn('open',[url]);
});
