#!/bin/zsh
cd -- "${0:A:h}"
for runtime in "/Applications/ChatGPT.app/Contents/Resources/cua_node/bin/node" "$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" "${commands[node]}" /opt/homebrew/bin/node /usr/local/bin/node; do
  if [[ -x "$runtime" ]] && "$runtime" -e 'process.exit(typeof fetch==="function"?0:1)'; then
    exec "$runtime" local.mjs
  fi
done
echo "请安装 Node.js 22 或更新版本，再双击启动。"
read -k 1
